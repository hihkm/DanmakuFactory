DanmakuFactory说明文档
版本：v1.30 release (2019/7/21)

》获取帮助
    使用教程：压缩包附有
              官网：http://tikm.org/df/help/
    建议反馈：hkm@tikm.org
    获取更新：github: https://github.com/HITIKM/DanmakuFactory/tree/master/release
              百度网盘: https://pan.baidu.com/s/1mkMaiq8AaUFUAGmv0s74vw 提取码：5vqj 

》注意事项
    新版本的编码转换依赖于WINAPI，经过测试并不完全可靠，在一些极端的情况下会引起程序的崩溃，目前正在尝试解决，因此请持续关注程序的更新，谢谢！涉及编码转换的最好在文本编辑器完成。

》关于
    本程序来源于一个开源于Github的项目DanmakuFactory( https://github.com/HITIKM/DanmakuFactory ),项目详情请见github的README.md
    作者：github:HITIKM/百度:hongkming/bilibili:10789290
    邮箱：hkm@tikm.org
    博客：tikm.org

》更新日志
    1.00
        初始版本
    1.10
        结构调整
    1.11
        *跟1.20其实是一个版本，不知怎么的当时就傻掉了╮(╯▽╰)╭
        UI微调
        逻辑优化
    1.30
        大规模修改UI，改善用户体验
        解决编码问题，支持ANSI与UTF-8，解决输入中文字体乱码问题
        增加批量转换
        增加命令行调用
        将配置文件存储为文本形式，并支持对旧二进制配置文件的转换
